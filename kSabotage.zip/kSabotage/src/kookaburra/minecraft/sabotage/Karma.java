
package kookaburra.minecraft.sabotage;

/**
 * Handles all Karma operations.
 * 
 * @author Alexander Mackenzie
 */
public class Karma
{
	public static final int MAX = 10000;
}
