/*
 * package kookaburra.minecraft.sabotage;
 * 
 * public class DeadBodyInfo {
 * 
 * public String name;
 * public boolean isInnocent;
 * public long deathTime;
 * 
 * public DeadBodyInfo(String name, boolean isInnocent)
 * {
 * this.name = name;
 * this.isInnocent = isInnocent;
 * deathTime = System.currentTimeMillis();
 * }
 * }
 */